const mongoose = require('mongoose');

const hairstyleSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true
  },
  category: {
    type: String,
    required: true,
    enum: ['Braids', 'Natural', 'Modern', 'Traditional', 'Protective', 'Locs']
  },
  gender: {
    type: String,
    required: true,
    enum: ['male', 'female', 'unisex']
  },
  thumbnail: {
    type: String,
    required: true
  },  
  ai_description: {
    type: String,
    required: true
  },
  price: {
    type: Number,
    required: true,
    min: 0,
    default: 0
  },
  tags: [{
    type: String,
    trim: true
  }],
  culturalOrigin: {
    type: String,
    trim: true
  },
  popularity: {
    type: Number,
    default: 0,
    min: 0,
    max: 100
  },
  estimatedTime: {
    type: String,
    default: '2-4 hours'
  },
  maintenance: {
    type: String,
    enum: ['Low', 'Medium', 'High'],
    default: 'Medium'
  },
  difficulty: {
    type: String,
    enum: ['Beginner', 'Intermediate', 'Advanced'],
    default: 'Intermediate'
  },
  isActive: {
    type: Boolean,
    default: true
  },
  isNew: {
    type: Boolean,
    default: false
  },
  isPremium: {
    type: Boolean,
    default: false
  },
  replicateModelId: {
    type: String,
    required: true
  },
  replicateVersion: {
    type: String,
    required: false
  },
  generationCount: {
    type: Number,
    default: 0
  },
  averageRating: {
    type: Number,
    default: 0,
    min: 0,
    max: 5
  },
  ratingCount: {
    type: Number,
    default: 0
  }
}, {
  timestamps: true
});

// Indexes
hairstyleSchema.index({ category: 1, gender: 1 });
hairstyleSchema.index({ popularity: -1 });
hairstyleSchema.index({ isActive: 1 });
hairstyleSchema.index({ tags: 1 });

// Method to increment generation count
hairstyleSchema.methods.incrementGeneration = function() {
  this.generationCount += 1;
  this.popularity = Math.min(100, this.popularity + 0.1); // Slight popularity boost
  return this.save();
};

// Static method to get popular hairstyles
hairstyleSchema.statics.getPopular = function(limit = 10) {
  return this.find({ isActive: true })
    .sort({ popularity: -1, generationCount: -1 })
    .limit(limit);
};

// Static method to search hairstyles
hairstyleSchema.statics.search = function(query, filters = {}) {
  const searchQuery = { isActive: true };
  
  if (query) {
    searchQuery.$or = [
      { name: { $regex: query, $options: 'i' } },
      { description: { $regex: query, $options: 'i' } },
      { tags: { $in: [new RegExp(query, 'i')] } },
      { culturalOrigin: { $regex: query, $options: 'i' } }
    ];
  }
  
  if (filters.category && filters.category !== 'All') {
    searchQuery.category = filters.category;
  }
  
  if (filters.gender && filters.gender !== 'All') {
    if (filters.gender === 'unisex') {
      searchQuery.gender = 'unisex';
    } else {
      searchQuery.$or = [
        { gender: filters.gender },
        { gender: 'unisex' }
      ];
    }
  }
  
  if (filters.isPremium !== undefined) {
    searchQuery.isPremium = filters.isPremium;
  }
  
  return this.find(searchQuery).sort({ popularity: -1 });
};

module.exports = mongoose.model('Hairstyle', hairstyleSchema);